export interface Stock {
  id: string;
  symbol: string;
  quantity: number;
  buy_price: number;
  current_price?: number;
  value?: number;
  gain_loss?: number;
  gain_loss_percentage?: number;
}

export interface User {
  id: string;
  email: string;
}