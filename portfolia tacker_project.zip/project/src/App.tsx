import React, { useState, useEffect } from 'react';
import { getCurrentUser, login, logout } from './services/authService';
import { addStock, updateStock, deleteStock } from './services/stockService';
import { useStocks } from './hooks/useStocks';
import { Dashboard } from './components/Dashboard';
import { StockList } from './components/StockList';
import { StockForm } from './components/StockForm';
import { LoadingSpinner } from './components/LoadingSpinner';
import { ErrorBoundary } from './components/ErrorBoundary';
import type { Stock, User } from './types';
import { Plus, LogOut } from 'lucide-react';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const { stocks, loading, error, refetch } = useStocks();
  const [showForm, setShowForm] = useState(false);
  const [editingStock, setEditingStock] = useState<Stock | null>(null);

  useEffect(() => {
    getCurrentUser().then(setUser);
  }, []);

  const handleAddStock = async (stockData: Partial<Stock>) => {
    try {
      if (!user) return;
      await addStock(stockData, user.id);
      setShowForm(false);
      refetch();
    } catch (error) {
      console.error('Error adding stock:', error);
    }
  };

  const handleUpdateStock = async (stockData: Partial<Stock>) => {
    try {
      if (!editingStock) return;
      await updateStock(editingStock.id, stockData);
      setEditingStock(null);
      setShowForm(false);
      refetch();
    } catch (error) {
      console.error('Error updating stock:', error);
    }
  };

  const handleDeleteStock = async (id: string) => {
    try {
      await deleteStock(id);
      refetch();
    } catch (error) {
      console.error('Error deleting stock:', error);
    }
  };

  const handleLogin = async () => {
    try {
      await login('demo@example.com', 'demo123');
    } catch (error) {
      console.error('Error logging in:', error);
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
      setUser(null);
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="max-w-md w-full bg-white rounded-lg shadow p-8">
          <h2 className="text-2xl font-bold text-center mb-6">Portfolio Tracker</h2>
          <button
            onClick={handleLogin}
            className="w-full bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700"
          >
            Login with Demo Account
          </button>
        </div>
      </div>
    );
  }

  if (loading) {
    return <LoadingSpinner />;
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="max-w-md w-full bg-white rounded-lg shadow p-8">
          <h2 className="text-2xl font-bold text-red-600 mb-4">Error</h2>
          <p className="text-gray-600 mb-4">{error}</p>
          <button
            onClick={refetch}
            className="w-full bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Portfolio Tracker</h1>
            <div className="flex space-x-4">
              <button
                onClick={() => {
                  setEditingStock(null);
                  setShowForm(true);
                }}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                <Plus className="h-5 w-5 mr-2" />
                Add Stock
              </button>
              <button
                onClick={handleLogout}
                className="flex items-center px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700"
              >
                <LogOut className="h-5 w-5 mr-2" />
                Logout
              </button>
            </div>
          </div>

          <Dashboard stocks={stocks} />

          <div className="mt-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Your Stocks</h2>
            <StockList
              stocks={stocks}
              onEdit={(stock) => {
                setEditingStock(stock);
                setShowForm(true);
              }}
              onDelete={handleDeleteStock}
            />
          </div>

          {showForm && (
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center">
              <div className="bg-white rounded-lg p-8 max-w-md w-full">
                <h2 className="text-xl font-semibold mb-4">
                  {editingStock ? 'Edit Stock' : 'Add New Stock'}
                </h2>
                <StockForm
                  stock={editingStock || undefined}
                  onSubmit={editingStock ? handleUpdateStock : handleAddStock}
                  onCancel={() => {
                    setShowForm(false);
                    setEditingStock(null);
                  }}
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </ErrorBoundary>
  );
}

export default App;