import { supabase } from '../lib/supabase';
import type { Stock } from '../types';

const FINNHUB_API_KEY = import.meta.env.VITE_FINNHUB_API_KEY;
const BASE_URL = 'https://finnhub.io/api/v1';

export async function fetchStockPrice(symbol: string): Promise<number> {
  try {
    const response = await fetch(
      `${BASE_URL}/quote?symbol=${symbol}&token=${FINNHUB_API_KEY}`
    );
    const data = await response.json();
    return data.c || 0; // Current price
  } catch (error) {
    console.error('Error fetching stock price:', error);
    return 0;
  }
}

export async function getStocks(): Promise<Stock[]> {
  const { data, error } = await supabase
    .from('stocks')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw error;

  const stocksWithMetrics = await Promise.all(
    data.map(async (stock) => {
      const currentPrice = await fetchStockPrice(stock.symbol);
      return {
        ...stock,
        current_price: currentPrice,
        value: currentPrice * stock.quantity,
        gain_loss: (currentPrice - stock.buy_price) * stock.quantity,
        gain_loss_percentage: ((currentPrice - stock.buy_price) / stock.buy_price) * 100,
      };
    })
  );

  return stocksWithMetrics;
}

export async function addStock(stockData: Partial<Stock>, userId: string) {
  const { error } = await supabase.from('stocks').insert([
    {
      ...stockData,
      user_id: userId,
    },
  ]);

  if (error) throw error;
}

export async function updateStock(id: string, stockData: Partial<Stock>) {
  const { error } = await supabase
    .from('stocks')
    .update(stockData)
    .eq('id', id);

  if (error) throw error;
}

export async function deleteStock(id: string) {
  const { error } = await supabase.from('stocks').delete().eq('id', id);
  if (error) throw error;
}