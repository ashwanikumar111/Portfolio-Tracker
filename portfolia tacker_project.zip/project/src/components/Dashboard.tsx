import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { DollarSign, TrendingUp, TrendingDown } from 'lucide-react';
import type { Stock } from '../types';

interface DashboardProps {
  stocks: Stock[];
}

export function Dashboard({ stocks }: DashboardProps) {
  const totalValue = stocks.reduce((sum, stock) => sum + (stock.value || 0), 0);
  const totalGainLoss = stocks.reduce((sum, stock) => sum + (stock.gain_loss || 0), 0);
  const topPerformer = stocks.reduce((top, stock) => {
    if (!top || (stock.gain_loss_percentage || 0) > (top.gain_loss_percentage || 0)) {
      return stock;
    }
    return top;
  }, null as Stock | null);

  const chartData = stocks.map(stock => ({
    name: stock.symbol,
    value: stock.value || 0,
    gainLoss: stock.gain_loss || 0
  }));

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <div className="p-2 bg-blue-100 rounded">
              <DollarSign className="h-6 w-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Total Portfolio Value</p>
              <p className="text-2xl font-semibold text-gray-900">${totalValue.toFixed(2)}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <div className={`p-2 rounded ${totalGainLoss >= 0 ? 'bg-green-100' : 'bg-red-100'}`}>
              {totalGainLoss >= 0 ? (
                <TrendingUp className="h-6 w-6 text-green-600" />
              ) : (
                <TrendingDown className="h-6 w-6 text-red-600" />
              )}
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Total Gain/Loss</p>
              <p className={`text-2xl font-semibold ${
                totalGainLoss >= 0 ? 'text-green-600' : 'text-red-600'
              }`}>
                ${totalGainLoss.toFixed(2)}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <div className="p-2 bg-purple-100 rounded">
              <TrendingUp className="h-6 w-6 text-purple-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Top Performer</p>
              <p className="text-2xl font-semibold text-gray-900">
                {topPerformer ? topPerformer.symbol : '-'}
              </p>
              {topPerformer && (
                <p className="text-sm text-green-600">
                  +{topPerformer.gain_loss_percentage?.toFixed(2)}%
                </p>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Portfolio Distribution</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="value" stroke="#3b82f6" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}